"""AstrBot QQ quote collector."""
